use ecommerce;
desc customers;
desc products;
desc orders;
desc order_items;

select * from products;
select * from customers;
select * from order_items;
select * from orders;

-- Which product has the highest price?
select product_name,price from products
		order by price desc;
        
-- Which customer has made the most orders?
select concat(first_name,' ',last_name)as full_name,count(*) as tot_orders from customers
		inner join orders
        using(customer_id)
        group by first_name,last_name
        order by tot_orders desc;

-- Which product has the highest total revenue? 

select product_name,(sum(quantity) * Price) as revenue  from products
		inner join order_items
        using(product_id)
        group by product_name,price
        order by revenue desc;
        
-- Find the top customer who have ordered the most distinct products

select concat(first_name,' ',last_name)as cust_name,product_name from customers
		inner join orders
        using(customer_id)
        inner join order_items
        using(order_id)
        inner join products
        using(product_id)
        group by first_name,last_name,product_name;
		
-- Find the first order (by date) for  customer "John Doe".

select * from customers
		inner join orders
        using(customer_id)
        where first_name='John' and last_name='Doe'
        order by order_date;






-- drop table products;
-- drop table customers;
-- drop table orders;
-- drop table order_items;