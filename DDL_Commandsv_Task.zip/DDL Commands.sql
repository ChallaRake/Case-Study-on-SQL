create database ProductDB;
use ProductDB;
create table Products(ProductID tinyint unique not null,
					ProductName varchar(255) not null,
                    Category varchar(255) not null,
                    Price smallint not null,
                    StockQuantity tinyint not null,
                    ManufactureDate date not null,
                    ExpiryDate date not null,
                    SupplierName varchar(255) default "unknown");

desc Products;

-- Add a Column
Alter table Products add column Description varchar(255) default "-";

-- Modify the Data Type of a Column
Alter table Products modify column Category char(50);
desc Products;

-- Drop a Column
Alter table Products drop column ExpiryDate;
desc Products;

-- Add a Constraint
Alter table Products add constraint unique(ProductName);
desc Products;

-- Drop a Constraint
Alter table Products drop constraint ProductName;
desc Products;

-- Change the Column Name
Alter table Products change column Price ProductPrice smallint;
desc Products;









