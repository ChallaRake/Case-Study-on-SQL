create database netflix_data;
use netflix_data;

create table netflix_data(show_id varchar(100),
							`type` varchar(100),
                            title	varchar(250),
                            director varchar(250),
                            `cast` text,
                            country	varchar(250),
                            date_added varchar(255),
                            release_year varchar(255),
                            rating	varchar(255),
                            duration varchar(255),
                            listed_in varchar(255),
                            `description` text);

select * from netflix_data;




/* What is the count the total number of records in the 
netflix_data table.*/
select count(*) from netflix_data;

/* What is the count the number of TV shows and movies 
separately */
select type,count(*)
		from  netflix_data
		group by type;
        
/* Find the top director with the most content on Netflix. */
select director,count(*) 
		from netflix_data
		group by director
        order by count(*) desc;
        
/* Find the most recently added title. */
select title,datediff(current_date(),str_to_date(date_added,'%M %d,%Y')) as date_diff
		from netflix_data
        order by date_diff;
        
/* What is  the Minimum release year for TV shows and 
movies. */
select `type`,min(release_year)-- `type` min(release_year)
		from netflix_data
        where release_year !=' Paul Sambo'
        group by `type`;
        -- order by release_year asc;

/* Find the top country with the most content on Netflix. */
select country,count(*) as freq
		from netflix_data
        where country != ''
        group by country
        order by freq desc;
        
/* Find the longest duration movie.*/
Select title, CAST(substring_index(duration," ",1) as unsigned) as duration_
	from netflix_data
    where type = "movie"
    order by duration_ desc;
        
select * from netflix_data;
