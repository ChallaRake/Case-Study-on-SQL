use ecommerce;

select * from customers;
select * from products;
select * from orders;
select * from order_items;


/* Find customers who have placed more orders than the average number of 
orders per customer. */

with cte_1 as (select first_name,count(*) as orders_ from customers
		left join orders
        using(customer_id)
        group by first_name),
cte_2 as (select avg(orders_) as avg_orders from cte_1)
select first_name,orders_ from cte_1
		where (select * from cte_2 where cte_1.orders_ > cte_2.avg_orders);
        
/* Explanation for above query:
	In the above Query i've performed the Common Table Expressions
    using left join with customers and orders and the 'group by' on first_name
    of customer, this is cte_1.
    And then next cte_2, where i've filtered the Avg no.of orders from cte_1.
    Finally filtered the first_name & orders_ who have ordered greater than 
    Avg no.of orders. */

-- ignore this below query
/*select avg(orders_) as avg_orders from (select first_name,count(*) as orders_ from customers
		inner join orders
        using(customer_id)
        group by first_name) as cust_ord
        ; */
        
        
-- Find products that have never been ordered.

-- Method-1        
select product_name from (select product_name,order_id from products
		left join order_items
        using(product_id)
        group by product_name,order_id) as s
        group by product_name;
        -- order by order_id;
 
 -- Method-2
select product_name from products
		where exists (select * from order_items 
					where products.product_id != order_items.product_id);
/* Eplanation:
   In this above query(Method-2) i've performed the Correlated Subquery to find the 
   the product which is never ordered as you can observe in the subquery
   that '(products.product_id) not equal to (order_items.product_id)' if it 
   is true for whichever product then that product is never ordered and it will
   return that particular . */
   
-- ignore this below query   
/* select product_name from products
		left join order_items
        using(product_id)
        group by product_name; */
   
/* Find customers who have never ordered a particular product 
(e.g., Product ID = 1):  */

with cte_1 as (select * from customers
		left join orders
        using(customer_id)),
cte_2 as (select * from cte_1
			left join order_items
            using(order_id))
select customer_id from cte_2
		where product_id = 1
        group by customer_id;

-- ignore this
/* Find customers who have never ordered a particular product 
(e.g., Product ID = 1):  */
select count(distinct customer_id) from orders
		where customer_id in (select customer_id from order_items where
        product_id = 1);
        
        
Select distinct product_id from order_items;