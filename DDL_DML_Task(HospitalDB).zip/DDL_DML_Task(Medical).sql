create database HospitalDB;
use HospitalDB;

create table Patients(PatientID tinyint auto_increment primary key,
					  FirstName varchar(255) not null,
                      LastName varchar(255),
                      DateOfBirth date,
                      Gender char(10),
                      ContactNumber char(12) not null unique,
                      Address varchar(255) default "unknown");
select * from Patients;
desc Patients;

create table Doctors(DoctorID tinyint auto_increment primary key,
					FirstName varchar(255) not null,
					LastName varchar(255),
                    Specialization varchar(255),
                    ContactNumber char(12) not null unique,
                    Email varchar(255));
select * from Doctors;
desc Doctors;

create table Appointments(AppointmentID tinyint auto_increment primary key,
						PatientID tinyint not null unique,
                        DoctorID tinyint not null unique,
                        AppointmentDate date,
                        Diagnosis varchar(255) default "unknown",
                        foreign key(PatientID) references Patients(PatientID)
                        on update cascade on delete cascade,
                        foreign key(DoctorID) references Doctors(DoctorID)
                        on update cascade on delete cascade);
select * from Appointments;
desc Appointments;

-- DDL Commands
-- Add a Column(Add a column named Email to the Patients table.)
alter table Patients add column Email varchar(255);
desc Patients;

-- Modify the Data Type of a Column(Change the datatype of the ContactNumber column in the Doctors table.)
alter table Doctors modify column ContactNumber char(10);
desc Doctors;

-- Remove the Address column from the Patients table.
alter table Patients drop column Address;
desc Patients;

-- Add a unique constraint to the Email column in the Doctors table.
alter table Doctors add constraint unique(Email);
desc Doctors;

-- Remove the unique constraint from the Email column in the Doctors table.
alter table Doctors drop index Email;
desc Doctors;

-- Rename the Diagnosis column to MedicalDiagnosis in the Appointments table.
alter table Appointments change column Diagnosis MedicalDiagnosis varchar(255);
desc Appointments;


select * from Patients;
-- DML Commands
-- Insert sample data into the Patients, Doctors, and Appointments tables.
insert into Patients(FirstName, LastName, DateOfBirth, Gender, ContactNumber, Email)
			values("Rakesh","Reddy","2002-06-20","Male","9949995028","rake@gmail.com"),
				("Jai","Varma","2000-05-16","Male","994562028","Jai12@gmail.com"),
                ("Sanjay","Sahu","1997-08-28","Male","845662028","Sanjay28@gmail.com"),
                ("Priya","reddy","2003-05-07","Female","842362028","Priya@gmail.com");
select * from Patients;

insert into Doctors(FirstName, LastName, Specialization, ContactNumber, Email)
			values("Sooraj","Kumar","Orthopedic","9943456780","Sooraj88@gmail.com"),
				("Madhu","Priya","Gynac","5182626262","Madhu12@gmail.com"),
                ("Chethan","naidu","Heart","7423336555","Chethan52@gmail.com"),
                ("Priyanka","reddy","Daermatologist","9874236654","Priyanka89@gmail.com");
select * from Doctors;

insert into Appointments(PatientID, DoctorID, AppointmentDate, MedicalDiagnosis)
			values(7,1,"2025-03-05","Broken Knee"),
				(8,2,"2024-08-25","fertility"),
                (5,4,"2024-03-14","Acne"),
                (6,3,"2024-01-24","ECG");
select * from Appointments;


-- Update the specialization of a doctor in the Doctors table.
update Doctors set Specialization = "Neurologist" where DoctorID = 1;
select * from Doctors;

-- Delete a patient record from the Patients table.
delete from Patients where PatientID = 7;
select * from Patients;

-- Retrieve all data from the Patients, Doctors, and Appointments tables.
select * from Patients;
select * from Doctors;
select * from Appointments;